<?php return array (
  'chat-box' => 'App\\Http\\Livewire\\ChatBox',
  'wordpress-create-post' => 'App\\Http\\Livewire\\WordpressCreatePost',
  'wordpress-seo' => 'App\\Http\\Livewire\\WordpressSeo',
);