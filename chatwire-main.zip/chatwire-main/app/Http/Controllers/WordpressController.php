<?php

namespace App\Http\Controllers;

class WordpressController extends Controller
{

    public function index()
    {
        return view('wordpress.index');
    }
}
